import React from 'react'
import '../styles/Home.css'

function Home() {
  return (
    <div className="home">
      <div className="headerContainer">
        <h1>THIS IS THE HOMEPAGE</h1>
      </div>
    </div>
  )
}

export default Home